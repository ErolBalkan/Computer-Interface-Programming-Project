select * from fitness;

-- insert into fitness
-- values(2,'Nikola','Zdenkovski',120,90,'you need to run 5km every day','Eat 2500 calloris daily');
-- insert into fitness
-- values(3,'Vladko','Velkovski',90,80,'you need to go swiming for 3 day a week','Eat 2000 calloris daily');
-- insert into fitness
-- values(4,'Marko','Markovski',130,75,'you need to do 3 sets of sit up','Eat 1500 calloris daily');
-- insert into fitness
-- values(5,'Filip','Trajkovski',115,85,'you need to go hikeing 2-3 days a week','Eat 1750 calloris daily');