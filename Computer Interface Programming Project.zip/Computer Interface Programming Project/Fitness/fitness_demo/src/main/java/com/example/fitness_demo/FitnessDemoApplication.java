package com.example.fitness_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

import javax.sql.DataSource;

@SpringBootApplication
public class FitnessDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FitnessDemoApplication.class, args);
	}

}
