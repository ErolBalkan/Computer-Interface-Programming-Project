package com.example.fitness_demo.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity(name = "Fitness's")
public class Fitness {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    private String fitness_name;
    private String fitness_lastname;
    private int weight;
    private int goal;
    private String d_workout;
    private String d_diet;

    public Fitness() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFitness_name() {
        return fitness_name;
    }

    public void setFitness_name(String fitness_name) {
        this.fitness_name = fitness_name;
    }

    public String getFitness_lastname() {
        return fitness_lastname;
    }

    public void setFitness_lastname(String fitness_lastname) {
        this.fitness_lastname = fitness_lastname;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public int getGoal() {
        return goal;
    }

    public void setGoal(int goal) {
        this.goal = goal;
    }

    public String getD_workout() {
        return d_workout;
    }

    public void setD_workout(String d_workout) {
        this.d_workout = d_workout;
    }

    public String getD_diet() {
        return d_diet;
    }

    public void setD_diet(String d_diet) {
        this.d_diet = d_diet;
    }
}
