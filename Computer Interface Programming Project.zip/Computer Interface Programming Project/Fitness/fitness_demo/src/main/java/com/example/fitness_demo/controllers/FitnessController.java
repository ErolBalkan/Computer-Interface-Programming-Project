package com.example.fitness_demo.controllers;

import com.example.fitness_demo.models.Fitness;
import com.example.fitness_demo.repositories.FitnessRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@RestController
@RequestMapping("api/v1/fitness")
public class FitnessController {
    @Autowired
    private FitnessRepository fitnessRepository;

//    public FitnessController(FitnessRepository fitnessRepository) {
//        this.fitnessRepository = fitnessRepository;
//    }

    @GetMapping
    public List<Fitness> list(){
        return fitnessRepository.findAll();
    }

    @GetMapping
    @RequestMapping("{fitness_id}")
    public Fitness get (@PathVariable Long fitness_id){
        return fitnessRepository.getOne(fitness_id);
    }

    @PostMapping
    public Fitness create(@RequestBody final Fitness fitness){
        return fitnessRepository.saveAndFlush(fitness);
    }
    @RequestMapping(value = "{fitness_id}", method = RequestMethod.DELETE)
    public void delete(@PathVariable Long fitness_id){
        fitnessRepository.deleteById(fitness_id);
    }
    @RequestMapping(value = "{fitness_id}", method = RequestMethod.PUT)
    public Fitness update(@PathVariable Long fitness_id, @RequestBody Fitness fitness){
        //Put Vs Patch
        Fitness existingFitness = fitnessRepository.getOne(fitness_id);
        BeanUtils.copyProperties(fitness, existingFitness,"fitness_id");
        return fitnessRepository.saveAndFlush(existingFitness);
    }
}
