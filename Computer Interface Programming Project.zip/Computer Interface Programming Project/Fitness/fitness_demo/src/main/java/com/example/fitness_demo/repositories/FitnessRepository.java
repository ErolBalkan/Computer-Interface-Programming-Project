package com.example.fitness_demo.repositories;

import com.example.fitness_demo.models.Fitness;
//import org.hibernate.boot.jaxb.internal.stax.JpaOrmXmlEventReader;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FitnessRepository extends JpaRepository<Fitness, Long> {

    List<Fitness> findall();
}